import { auth } from "@/lib/auth";
import { NextResponse } from "next/server";

export default auth((req) => {
  const isLoggedIn = !!req.auth;
  const isStaffRoute = req.nextUrl.pathname.startsWith("/staff");
  const isDashboard = req.nextUrl.pathname.startsWith("/dashboard");

  if ((isDashboard || isStaffRoute) && !isLoggedIn) {
    return NextResponse.redirect(new URL("/login", req.url));
  }

  if (isStaffRoute && isLoggedIn) {
    const role = req.auth?.user?.role;
    if (role !== "staff" && role !== "admin") {
      return NextResponse.redirect(new URL("/dashboard", req.url));
    }
  }

  return NextResponse.next();
});

export const config = {
  matcher: ["/dashboard/:path*", "/staff/:path*"],
};
