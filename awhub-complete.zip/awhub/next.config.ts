import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Keep static Lua files accessible
};

export default nextConfig;
