"use client";

import { useState } from "react";
import Link from "next/link";

export default function HomePage() {
  const [copied, setCopied] = useState(false);
  const loadstring = `loadstring(game:HttpGet("https://applewareh.vercel.app/full.lua"))()`;

  function copyScript() {
    navigator.clipboard.writeText(loadstring).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  return (
    <>
      {/* Hero */}
      <section className="hero-bg min-h-screen flex items-center pt-20">
        <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-3 px-5 py-2 bg-white/5 rounded-3xl border border-white/10">
              <span className="text-emerald-400 text-xl">●</span>
              <span className="font-medium">Keyless • 0 Delay • Anti-fling • Auto-rejoin</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight leading-tight">
              AWHUB
            </h1>
            <p className="text-xl text-zinc-300 leading-relaxed">
              The best keyless Murder Mystery 2 auto farm script.
              <br />
              Copy, execute, and farm — no keys, no friction.
            </p>
            <div className="flex flex-wrap gap-4">
              <a
                href="#script"
                className="inline-flex items-center gap-3 bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:opacity-90 px-8 py-4 rounded-2xl font-semibold text-lg transition"
              >
                Get Script
              </a>
              <Link
                href="/dashboard"
                className="inline-flex items-center gap-3 glass px-8 py-4 rounded-2xl font-semibold text-lg hover:border-violet-400/50 transition"
              >
                Open a Ticket
              </Link>
            </div>
          </div>

          <div className="glass rounded-3xl p-12 glow">
            <div className="flex items-center gap-5 mb-10">
              <div className="w-20 h-20 bg-gradient-to-br from-violet-500 to-fuchsia-500 rounded-3xl flex items-center justify-center text-3xl font-black shadow-2xl">
                AW
              </div>
              <div>
                <h2 className="text-4xl font-bold tracking-tight">AWHUB</h2>
                <p className="text-zinc-400 text-lg">v1 · Keyless</p>
              </div>
            </div>
            <p className="text-zinc-300 text-lg leading-relaxed mb-10">
              Underground auto farm • Bag full automation • Anti-fling • Auto rejoin
            </p>
            <a
              href="#script"
              className="block w-full bg-gradient-to-r from-violet-500 to-fuchsia-500 font-semibold py-4 rounded-2xl text-center text-lg hover:scale-[1.02] transition"
            >
              Copy Loadstring
            </a>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-24 bg-zinc-950">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-5xl font-bold text-center mb-16">Powerful Features</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Underground Farm",
                desc: "Completely hidden under the map with zero delay coin collection.",
                icon: "🛡️",
              },
              {
                title: "Bag Full Automation",
                desc: "Auto fling/kill/shoot when your bag reaches capacity.",
                icon: "⚡",
              },
              {
                title: "Anti-Detection Suite",
                desc: "Anti-fling, anti-AFK, auto rejoin on kick.",
                icon: "🔒",
              },
            ].map((f) => (
              <div key={f.title} className="glass rounded-3xl p-10">
                <div className="text-5xl mb-6">{f.icon}</div>
                <h3 className="text-2xl font-semibold mb-4">{f.title}</h3>
                <p className="text-zinc-400">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Script */}
      <section id="script" className="py-24 bg-zinc-900">
        <div className="max-w-4xl mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-4">Get the Script</h2>
          <p className="text-zinc-400 text-center mb-12 text-lg">
            Keyless. Copy the loadstring and paste into your executor.
          </p>

          <div className="glass rounded-3xl overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <span className="font-mono text-sm text-zinc-400">LOADSTRING.LUA</span>
                <span className="px-2 py-0.5 text-xs font-semibold bg-emerald-500/20 text-emerald-400 rounded-full">
                  KEYLESS
                </span>
              </div>
              <button
                onClick={copyScript}
                className="inline-flex items-center gap-2 bg-violet-600 hover:bg-violet-700 px-4 py-2 rounded-xl text-sm font-semibold transition"
              >
                {copied ? "✓ Copied!" : "Copy Script"}
              </button>
            </div>
            <div className="p-6 code-box text-sm text-violet-200 overflow-x-auto">
              <code>{loadstring}</code>
            </div>
          </div>

          <div className="mt-10 grid md:grid-cols-3 gap-6 text-center">
            {["Copy the script above", "Open your Roblox executor", "Paste & execute in MM2"].map(
              (step, i) => (
                <div key={i} className="glass rounded-2xl p-6">
                  <div className="w-10 h-10 mx-auto mb-3 rounded-full bg-violet-500/20 flex items-center justify-center text-violet-400 font-bold">
                    {i + 1}
                  </div>
                  <p className="text-zinc-300">{step}</p>
                </div>
              )
            )}
          </div>
        </div>
      </section>

      {/* Support CTA */}
      <section className="py-24 bg-zinc-950">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-4xl font-bold mb-6">Need Help?</h2>
          <p className="text-zinc-400 text-lg mb-10">
            Open a support ticket — staff will reply on the site and in Discord.
          </p>
          <Link
            href="/dashboard"
            className="inline-flex items-center gap-3 bg-gradient-to-r from-violet-500 to-fuchsia-500 px-10 py-4 rounded-2xl font-semibold text-lg hover:scale-[1.02] transition"
          >
            Open Support Ticket
          </Link>
        </div>
      </section>

      <footer className="py-12 text-center text-zinc-500 border-t border-white/10">
        <p className="text-lg">applewareh.vercel.app · keyless</p>
      </footer>
    </>
  );
}
