"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Link from "next/link";

type Ticket = {
  id: string;
  subject: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  user: { id: string; name: string | null; email: string | null; image: string | null };
  _count: { messages: number };
  messages: { content: string }[];
};

export default function StaffPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    if (status === "unauthenticated") router.push("/login");
    if (
      status === "authenticated" &&
      session?.user?.role !== "staff" &&
      session?.user?.role !== "admin"
    ) {
      router.push("/dashboard");
    }
  }, [status, session, router]);

  useEffect(() => {
    if (session?.user?.role === "staff" || session?.user?.role === "admin") {
      fetch("/api/tickets")
        .then((r) => r.json())
        .then((data) => {
          setTickets(Array.isArray(data) ? data : []);
          setLoading(false);
        })
        .catch(() => setLoading(false));
    }
  }, [session]);

  async function updateStatus(id: string, newStatus: string) {
    await fetch(`/api/tickets/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: newStatus }),
    });
    setTickets((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status: newStatus } : t))
    );
  }

  if (status === "loading" || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-20">
        <p className="text-zinc-400">Loading staff panel...</p>
      </div>
    );
  }

  const filtered =
    filter === "all" ? tickets : tickets.filter((t) => t.status === filter);

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-2">Staff Panel</h1>
        <p className="text-zinc-400 mb-8">Manage all support tickets</p>

        {/* Filters */}
        <div className="flex gap-2 mb-6">
          {["all", "open", "pending", "closed"].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-1.5 rounded-xl text-sm font-medium transition ${
                filter === f
                  ? "bg-violet-600 text-white"
                  : "bg-white/5 text-zinc-400 hover:bg-white/10"
              }`}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="glass rounded-2xl p-12 text-center text-zinc-400">
            No tickets found
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((t) => (
              <div key={t.id} className="glass rounded-2xl p-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <Link
                      href={`/dashboard/tickets/${t.id}`}
                      className="font-semibold hover:text-violet-400 transition"
                    >
                      {t.subject}
                    </Link>
                    <p className="text-sm text-zinc-400 mt-1 line-clamp-1">
                      {t.messages[0]?.content}
                    </p>
                    <p className="text-xs text-zinc-500 mt-2">
                      {t.user.name || t.user.email} ·{" "}
                      {new Date(t.updatedAt).toLocaleString()} ·{" "}
                      {t._count.messages} msgs
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <select
                      value={t.status}
                      onChange={(e) => updateStatus(t.id, e.target.value)}
                      className="bg-white/10 border border-white/10 rounded-lg px-2 py-1 text-xs focus:outline-none"
                    >
                      <option value="open">Open</option>
                      <option value="pending">Pending</option>
                      <option value="closed">Closed</option>
                    </select>
                    <Link
                      href={`/dashboard/tickets/${t.id}`}
                      className="bg-violet-600 hover:bg-violet-700 px-3 py-1.5 rounded-lg text-xs font-semibold transition"
                    >
                      Reply
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
