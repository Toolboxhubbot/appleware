"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Link from "next/link";

type Ticket = {
  id: string;
  subject: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  _count: { messages: number };
  messages: { content: string; createdAt: string }[];
};

export default function DashboardPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [subject, setSubject] = useState("");
  const [content, setContent] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login");
    }
  }, [status, router]);

  useEffect(() => {
    if (session) {
      fetch("/api/tickets")
        .then((r) => r.json())
        .then((data) => {
          setTickets(Array.isArray(data) ? data : []);
          setLoading(false);
        })
        .catch(() => setLoading(false));
    }
  }, [session]);

  async function createTicket(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);

    const res = await fetch("/api/tickets", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ subject: subject || "Support Request", content }),
    });

    setSubmitting(false);
    if (res.ok) {
      const ticket = await res.json();
      router.push(`/dashboard/tickets/${ticket.id}`);
    }
  }

  if (status === "loading" || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-20">
        <p className="text-zinc-400">Loading...</p>
      </div>
    );
  }

  if (!session) return null;

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Support Tickets</h1>
            <p className="text-zinc-400 mt-1">
              Hi {session.user.name || session.user.email}
            </p>
          </div>
          <button
            onClick={() => setShowForm(!showForm)}
            className="bg-violet-600 hover:bg-violet-700 px-5 py-2.5 rounded-xl font-semibold transition"
          >
            {showForm ? "Cancel" : "+ New Ticket"}
          </button>
        </div>

        {showForm && (
          <form
            onSubmit={createTicket}
            className="glass rounded-2xl p-6 mb-8 space-y-4"
          >
            <div>
              <label className="block text-sm text-zinc-400 mb-1.5">Subject</label>
              <input
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g. Script not loading"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-violet-500"
              />
            </div>
            <div>
              <label className="block text-sm text-zinc-400 mb-1.5">Message</label>
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                required
                rows={4}
                placeholder="Describe your issue..."
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-violet-500 resize-none"
              />
            </div>
            <button
              type="submit"
              disabled={submitting || content.length < 5}
              className="bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:opacity-90 disabled:opacity-50 px-6 py-3 rounded-xl font-semibold transition"
            >
              {submitting ? "Creating..." : "Submit Ticket"}
            </button>
          </form>
        )}

        {tickets.length === 0 ? (
          <div className="glass rounded-2xl p-12 text-center">
            <p className="text-zinc-400 mb-4">No tickets yet</p>
            <button
              onClick={() => setShowForm(true)}
              className="text-violet-400 hover:text-violet-300 font-medium"
            >
              Create your first ticket →
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {tickets.map((t) => (
              <Link
                key={t.id}
                href={`/dashboard/tickets/${t.id}`}
                className="glass rounded-2xl p-5 flex items-center justify-between hover:border-violet-400/40 transition block"
              >
                <div>
                  <h3 className="font-semibold">{t.subject}</h3>
                  <p className="text-sm text-zinc-400 mt-1 line-clamp-1">
                    {t.messages[0]?.content || "No messages"}
                  </p>
                  <p className="text-xs text-zinc-500 mt-2">
                    {new Date(t.updatedAt).toLocaleString()} · {t._count.messages} messages
                  </p>
                </div>
                <span
                  className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    t.status === "open"
                      ? "bg-emerald-500/20 text-emerald-400"
                      : t.status === "pending"
                      ? "bg-amber-500/20 text-amber-400"
                      : "bg-zinc-500/20 text-zinc-400"
                  }`}
                >
                  {t.status}
                </span>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
