"use client";

import { useSession } from "next-auth/react";
import { useRouter, useParams } from "next/navigation";
import { useEffect, useState, useRef } from "react";
import Link from "next/link";

type Message = {
  id: string;
  content: string;
  isStaff: boolean;
  createdAt: string;
  user: { id: string; name: string | null; image: string | null } | null;
};

type Ticket = {
  id: string;
  subject: string;
  status: string;
  createdAt: string;
  user: { id: string; name: string | null; email: string | null };
  messages: Message[];
};

export default function TicketPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;
  const [ticket, setTicket] = useState<Ticket | null>(null);
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState("");
  const [sending, setSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (status === "unauthenticated") router.push("/login");
  }, [status, router]);

  function loadTicket() {
    fetch(`/api/tickets/${id}`)
      .then((r) => r.json())
      .then((data) => {
        if (data.error) router.push("/dashboard");
        else {
          setTicket(data);
          setLoading(false);
        }
      })
      .catch(() => setLoading(false));
  }

  useEffect(() => {
    if (session) loadTicket();
  }, [session, id]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [ticket?.messages]);

  async function sendMessage(e: React.FormEvent) {
    e.preventDefault();
    if (!content.trim()) return;
    setSending(true);

    const res = await fetch(`/api/tickets/${id}/messages`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content }),
    });

    setSending(false);
    if (res.ok) {
      setContent("");
      loadTicket();
    }
  }

  if (status === "loading" || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-20">
        <p className="text-zinc-400">Loading ticket...</p>
      </div>
    );
  }

  if (!ticket) return null;

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-3xl mx-auto">
        <Link
          href="/dashboard"
          className="text-sm text-zinc-400 hover:text-violet-400 transition mb-4 inline-block"
        >
          ← Back to tickets
        </Link>

        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">{ticket.subject}</h1>
            <p className="text-sm text-zinc-400 mt-1">
              Opened {new Date(ticket.createdAt).toLocaleString()}
            </p>
          </div>
          <span
            className={`px-3 py-1 rounded-full text-xs font-semibold ${
              ticket.status === "open"
                ? "bg-emerald-500/20 text-emerald-400"
                : ticket.status === "pending"
                ? "bg-amber-500/20 text-amber-400"
                : "bg-zinc-500/20 text-zinc-400"
            }`}
          >
            {ticket.status}
          </span>
        </div>

        {/* Messages */}
        <div className="glass rounded-2xl p-6 mb-6 space-y-4 max-h-[55vh] overflow-y-auto">
          {ticket.messages.map((m) => (
            <div
              key={m.id}
              className={`flex ${m.isStaff ? "justify-start" : "justify-end"}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                  m.isStaff
                    ? "bg-violet-600/30 border border-violet-500/30"
                    : "bg-white/10"
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-semibold">
                    {m.isStaff
                      ? "🛡️ Staff"
                      : m.user?.name || "You"}
                  </span>
                  <span className="text-xs text-zinc-500">
                    {new Date(m.createdAt).toLocaleString()}
                  </span>
                </div>
                <p className="text-sm whitespace-pre-wrap">{m.content}</p>
              </div>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        {/* Reply */}
        {ticket.status !== "closed" ? (
          <form onSubmit={sendMessage} className="flex gap-3">
            <input
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Type a reply..."
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-violet-500"
            />
            <button
              type="submit"
              disabled={sending || !content.trim()}
              className="bg-violet-600 hover:bg-violet-700 disabled:opacity-50 px-6 py-3 rounded-xl font-semibold transition"
            >
              {sending ? "..." : "Send"}
            </button>
          </form>
        ) : (
          <p className="text-center text-zinc-500 text-sm">
            This ticket is closed.
          </p>
        )}
      </div>
    </div>
  );
}
