import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { postToThread } from "@/lib/discord";
import { z } from "zod";

const messageSchema = z.object({
  content: z.string().min(1).max(4000),
});

// POST /api/tickets/[id]/messages
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const isStaff = session.user.role === "staff" || session.user.role === "admin";

  const ticket = await prisma.ticket.findUnique({ where: { id } });
  if (!ticket) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  if (!isStaff && ticket.userId !== session.user.id) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  if (ticket.status === "closed") {
    return NextResponse.json(
      { error: "Ticket is closed" },
      { status: 400 }
    );
  }

  try {
    const body = await req.json();
    const parsed = messageSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid content" }, { status: 400 });
    }

    const message = await prisma.message.create({
      data: {
        ticketId: id,
        userId: session.user.id,
        content: parsed.data.content,
        isStaff,
      },
      include: {
        user: { select: { id: true, name: true, image: true } },
      },
    });

    // Update ticket timestamp
    await prisma.ticket.update({
      where: { id },
      data: { updatedAt: new Date() },
    });

    // Mirror to Discord thread
    if (ticket.discordThreadId) {
      await postToThread(
        ticket.discordThreadId,
        parsed.data.content,
        isStaff,
        session.user.name || "User"
      );
    }

    return NextResponse.json(message, { status: 201 });
  } catch (err) {
    console.error("Post message error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
