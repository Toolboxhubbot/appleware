import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { createTicketThread } from "@/lib/discord";
import { z } from "zod";

const createSchema = z.object({
  subject: z.string().min(3).max(120).default("Support Request"),
  content: z.string().min(5).max(4000),
});

// GET /api/tickets – list current user's tickets (or all if staff)
export async function GET() {
  const session = await auth();
  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const isStaff = session.user.role === "staff" || session.user.role === "admin";

  const tickets = await prisma.ticket.findMany({
    where: isStaff ? {} : { userId: session.user.id },
    include: {
      user: { select: { id: true, name: true, image: true, email: true } },
      messages: {
        orderBy: { createdAt: "desc" },
        take: 1,
      },
      _count: { select: { messages: true } },
    },
    orderBy: { updatedAt: "desc" },
  });

  return NextResponse.json(tickets);
}

// POST /api/tickets – create a new ticket
export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const parsed = createSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid input", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const { subject, content } = parsed.data;

    // Create Discord thread first (optional – continues even if it fails)
    const threadId = await createTicketThread(
      subject,
      session.user.name || session.user.email || "User",
      content
    );

    const ticket = await prisma.ticket.create({
      data: {
        userId: session.user.id,
        subject,
        status: "open",
        discordThreadId: threadId,
        messages: {
          create: {
            userId: session.user.id,
            content,
            isStaff: false,
          },
        },
      },
      include: {
        messages: true,
      },
    });

    return NextResponse.json(ticket, { status: 201 });
  } catch (err) {
    console.error("Create ticket error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
