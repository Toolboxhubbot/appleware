Place full.lua and main.lua in this folder (or keep them at repo root and serve via Vercel rewrites).
