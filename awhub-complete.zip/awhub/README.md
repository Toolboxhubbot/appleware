# AWHUB — Keyless MM2 Script + Support System

Full Next.js 15 app with:

- Discord + email/password auth (NextAuth v5)
- Support ticket system backed by PostgreSQL
- Discord private thread sync for every ticket
- User dashboard + staff panel

## Quick Start

### 1. Install

```bash
npm install
```

### 2. Environment

Copy `.env.example` → `.env` and fill in:

```env
DATABASE_URL=          # Neon / Supabase / Vercel Postgres
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=       # openssl rand -base64 32
DISCORD_CLIENT_ID=
DISCORD_CLIENT_SECRET=
DISCORD_BOT_TOKEN=
DISCORD_TICKETS_CHANNEL_ID=
```

### 3. Database

```bash
npx prisma db push
```

### 4. Run

```bash
npm run dev
```

Open http://localhost:3000

## Discord Setup

1. Create an application at https://discord.com/developers/applications
2. **OAuth2** → add redirect `http://localhost:3000/api/auth/callback/discord` (and your production URL)
3. **Bot** → create a bot, enable Message Content Intent, copy token
4. Invite the bot to your server with `Manage Threads` + `Send Messages` permissions
5. Create a channel for tickets and put its ID in `DISCORD_TICKETS_CHANNEL_ID`

## Making someone staff

```sql
UPDATE "User" SET role = 'staff' WHERE email = 'you@example.com';
-- or
UPDATE "User" SET role = 'admin' WHERE "discordId" = 'YOUR_DISCORD_ID';
```

## Deploy to Vercel

1. Push this repo
2. Import on Vercel
3. Add all env vars
4. Deploy (build command already runs `prisma generate`)

Make sure `full.lua` stays in the public root (or `public/`) so the loadstring keeps working.

## Project Structure

```
app/
  page.tsx              # Landing page
  login/                # Auth page
  dashboard/            # User ticket list + create
  dashboard/tickets/[id]# Ticket conversation
  staff/                # Staff panel
  api/auth/             # NextAuth
  api/tickets/          # Ticket CRUD + messages
lib/
  auth.ts               # NextAuth config
  prisma.ts             # DB client
  discord.ts            # Thread creation helper
prisma/schema.prisma    # Your models
```
