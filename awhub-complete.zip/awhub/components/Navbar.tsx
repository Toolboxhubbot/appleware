"use client";

import Link from "next/link";
import { useSession, signOut } from "next-auth/react";

export function Navbar() {
  const { data: session } = useSession();

  return (
    <nav className="fixed top-0 w-full z-50 border-b border-white/10 bg-black/80 backdrop-blur-xl">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3">
          <div className="w-9 h-9 bg-gradient-to-br from-violet-500 to-fuchsia-500 rounded-2xl flex items-center justify-center font-bold text-lg">
            AW
          </div>
          <span className="font-bold text-2xl tracking-tighter">AWHUB</span>
        </Link>

        <div className="flex items-center gap-6 text-sm font-medium">
          <Link href="/#features" className="hover:text-violet-400 transition hidden sm:block">
            Features
          </Link>
          <Link href="/#script" className="hover:text-violet-400 transition hidden sm:block">
            Script
          </Link>
          <Link href="/dashboard" className="hover:text-violet-400 transition">
            Support
          </Link>

          {session?.user ? (
            <div className="flex items-center gap-3">
              {(session.user.role === "staff" || session.user.role === "admin") && (
                <Link
                  href="/staff"
                  className="text-emerald-400 hover:text-emerald-300 transition"
                >
                  Staff
                </Link>
              )}
              <span className="text-zinc-400 text-xs hidden md:inline">
                {session.user.name || session.user.email}
              </span>
              <button
                onClick={() => signOut()}
                className="bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-xl text-xs transition"
              >
                Sign out
              </button>
            </div>
          ) : (
            <Link
              href="/login"
              className="bg-violet-600 hover:bg-violet-700 px-4 py-2 rounded-xl text-sm font-semibold transition"
            >
              Login
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}
