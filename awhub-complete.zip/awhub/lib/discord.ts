/**
 * Discord helper – creates a private thread for a support ticket
 * and posts the initial message.
 */

const DISCORD_API = "https://discord.com/api/v10";

export async function createTicketThread(
  subject: string,
  userName: string,
  content: string
): Promise<string | null> {
  const token = process.env.DISCORD_BOT_TOKEN;
  const channelId = process.env.DISCORD_TICKETS_CHANNEL_ID;

  if (!token || !channelId) {
    console.warn("Discord bot token or tickets channel not configured");
    return null;
  }

  try {
    // Create a private thread
    const threadRes = await fetch(
      `${DISCORD_API}/channels/${channelId}/threads`,
      {
        method: "POST",
        headers: {
          Authorization: `Bot ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: `ticket-${subject.slice(0, 80)}`.slice(0, 100),
          type: 12, // PRIVATE_THREAD
          auto_archive_duration: 10080, // 7 days
          invitable: false,
        }),
      }
    );

    if (!threadRes.ok) {
      console.error("Failed to create Discord thread", await threadRes.text());
      return null;
    }

    const thread = await threadRes.json();
    const threadId = thread.id as string;

    // Post the initial message
    await fetch(`${DISCORD_API}/channels/${threadId}/messages`, {
      method: "POST",
      headers: {
        Authorization: `Bot ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        content: `**New Support Ticket**\n**From:** ${userName}\n**Subject:** ${subject}\n\n${content}`,
      }),
    });

    return threadId;
  } catch (err) {
    console.error("Discord thread creation error:", err);
    return null;
  }
}

export async function postToThread(
  threadId: string,
  content: string,
  isStaff: boolean,
  authorName: string
): Promise<boolean> {
  const token = process.env.DISCORD_BOT_TOKEN;
  if (!token || !threadId) return false;

  try {
    const prefix = isStaff ? "🛡️ **Staff**" : `👤 **${authorName}**`;
    const res = await fetch(`${DISCORD_API}/channels/${threadId}/messages`, {
      method: "POST",
      headers: {
        Authorization: `Bot ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        content: `${prefix}\n${content}`,
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}
